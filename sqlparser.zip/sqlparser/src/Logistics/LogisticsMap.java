package Logistics;

public class LogisticsMap {

}
