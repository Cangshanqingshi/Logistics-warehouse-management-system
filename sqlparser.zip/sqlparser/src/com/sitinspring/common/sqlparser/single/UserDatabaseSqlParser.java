package com.sitinspring.common.sqlparser.single;

public class UserDatabaseSqlParser {

}
